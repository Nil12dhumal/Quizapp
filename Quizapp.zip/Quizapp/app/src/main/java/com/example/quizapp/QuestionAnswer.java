package com.example.quizapp;

public class QuestionAnswer {

    public static String question[] ={

            "Which company owns the android?",
            "Which one is not the programming language?",
            "In which year India became T20 World Cup champion for the first time?",
            "Which is the national sport of India?",
            "Who was the First Prime Minister of India?"


    };

    public static String choices[][]={
            {"Google","Apple","Nokia","Samsung"},
            {"Java","Python","Notepad","Kotlin"},
            {"2011","2007","2024","2017"},
            {"Cricket","Hockey","kabaddi","kho-kho"},
            {"Narendra Modi","Indira Gandhi","Jawaharal Nehru","Manmohan Singh"}


    };

    public static String correctAnswers[]={

            "Google",
            "Notepad",
            "2007",
            "Hockey",
            "Jawaharal Nehru"

    };
}
